---
name: frontend-design
description: >
  Create distinctive, production-grade frontend interfaces with award-winning
  design quality inspired by Awwwards, FWA, and Webby winners. Use this skill
  ALWAYS when the user asks to build ANY web interface: websites, landing pages,
  dashboards, React components, HTML/CSS layouts, portfolios, e-commerce pages,
  apps, posters, or when styling/beautifying any web UI. Also trigger when the
  user mentions premium design, award-winning, cinematic, immersive, luxury feel,
  Awwwards level, or wants anything visually striking for the web. This skill
  adapts across all complexity levels from elegant static HTML to full React with
  GSAP and Three.js experiences. NEVER produce generic template-looking output.
  Every creation must feel like it could win a design award.
---

# Award-Winning Frontend Design System v3

This skill creates frontend interfaces at the level of Awwwards Site of the Year winners. It fuses 200+ design and animation techniques extracted from studios like Lusion, Igloo Inc, Active Theory, Locomotive, Cuberto, Phantom, Studio Freight, Fantasy, Hello Monday, Noomo, Fiddle Digital, Immersive Garden, and brands like Cartier, Porsche, Louis Vuitton into a reproducible creative system.

**Before writing ANY code**, Claude must read the appropriate reference files:
- `references/PATTERNS.md` — Core patterns (Tier 0-2): CSS-native animations, scroll reveals, cursors, typography, buttons, layouts, colors, fonts, glassmorphism, skeletons, accordions, OKLCH, gradients
- `references/ADVANCED.md` — Advanced patterns (Tier 2-4): SVG filters, kinetic type, page transitions, spotlight, video scrub, stacking cards, spring physics, canvas grain, 3D parallax, variable fonts, glitch, aurora, image sequences, audio, Barba.js, Spline, model-viewer, cursor trails

## Phase 1: Design Intelligence (BEFORE any code)

### 1. Project Classification
- **Immersive Experience** → WebGL, scroll-driven narrative (Lusion, Igloo, Active Theory)
- **Creative Agency / Portfolio** → Bold typography, smooth transitions (Locomotive, Phantom, Fiddle)
- **Luxury / Brand** → Restrained elegance, cinematic imagery (Cartier, Louis Vuitton, Porsche)
- **Product / E-Commerce** → Conversion focus, product hero moments (Away, Glossier, ETQ)
- **Dashboard / App** → Data density with breathing room, micro-interactions
- **Editorial / Storytelling** → Scroll-driven narrative, parallax, magazine typography

### 2. Aesthetic Direction
- **Single memorable concept** — what will someone screenshot?
- **Color in OKLCH** — vibrant gradients without muddy midtones. `color-mix(in oklch, ...)` for derived shades.
- **2 fonts max** — consider variable fonts for animated weight/width
- **Motion personality** — cinematic slow, playful bounce, surgical precision, organic flow

### 3. Technical Tier Selection
- **Tier 0 — CSS-Native** *(2025-2026)*: scroll-driven animations, @starting-style, @property, linear() springs, interpolate-size, View Transitions, dialog/popover. Zero JS. 60fps off-thread.
- **Tier 1 — Pure CSS/HTML**: animations, scroll-snap, grid, blend modes, clip-path, glassmorphism, aurora, skeleton screens.
- **Tier 2 — CSS + Vanilla JS**: cursors (spring, trails, blobs), magnetic buttons, text split, Lenis, SVG filters, Web Audio, canvas grain.
- **Tier 3 — React + Libraries**: Motion/Framer Motion, GSAP + all plugins, Barba.js, Rive, Lottie.
- **Tier 4 — 3D/WebGL**: Three.js, OGL, Curtains.js, PixiJS, Spline, model-viewer.

## Phase 2: The 18 Commandments

Every output MUST demonstrate at least 10:

### C1: HERO DOMINATION
Full-viewport (100svh). ONE focal point. Orchestrated entry. CSS `view()` timeline for exit.

### C2: TYPOGRAPHIC HIERARCHY AS ARCHITECTURE
Headlines 8-15vw with `clamp()`. Variable font animation. Text gradient shimmer. Text mask with video. Preferred fonts: Clash Display, Satoshi, Cabinet Grotesk, Syne, Instrument Serif, Playfair Display, DM Serif Display, Cormorant Garamond, Manrope, General Sans, Fraunces. BANNED: Inter, Roboto, Arial, Open Sans, Lato, Montserrat, Poppins. `font-display: swap` always.

### C3: INTENTIONAL MOTION CHOREOGRAPHY
Page load stagger (50-120ms). CSS scroll-driven `view()` for reveals (prefer over IO). CSS `linear()` spring easing. `@starting-style` for display:none. Custom cubic-beziers only.

### C4: SPATIAL COMPOSITION & LAYOUT BREAKING
Asymmetric splits. Bento grids with Container Queries. Overlapping elements. CSS Subgrid. `:has()` conditional layouts.

### C5: DARK MODE AS DEFAULT LUXURY
Near-black `#0a0a0a`. Off-white `#e5e5e5`. `light-dark()` function. `color-scheme: light dark`. OKLCH accents. `color-mix()` for derived shades.

### C6: CURSOR AS INTERACTION LAYER
Spring physics cursor. Trails (fading dots, ribbons, particles). Blob/fluid morphing. Momentum stretch via `skew()`. Multi-state (default, hover, drag, labeled). Spotlight/magnifier mode. `mix-blend-mode: difference`. GSAP `quickTo()`. Hide on `(hover: none)`.

### C7: SCROLL AS NARRATIVE DEVICE
Lenis smooth scroll. CSS `scroll()` timeline for off-thread parallax. GSAP ScrollTrigger pin+scrub. Horizontal scroll sections. Scroll velocity → blur/skew/scale. Progress indicators.

### C8: IMAGE & MEDIA TREATMENT
Clip-path/mask reveals. 3D tilt+glare hover. Ken Burns CSS. LQIP/BlurHash placeholders. Image comparison slider. Canvas image sequences. `content-visibility: auto`. Video scroll scrub.

### C9: MICRO-INTERACTIONS & FEEDBACK
Button fill/draw/ripple/magnetic/tilt/glow/sweep. Accordion `grid-template-rows: 0fr→1fr`. Native `<dialog>` + `@starting-style`. Popover API. Skeleton shimmer. Number counters. Dark mode circle toggle. Toast `@starting-style`. Floating label CSS-only.

### C10: RESPONSIVE AS REDESIGN
`clamp()` fluid sizing. Container Queries. Full-screen mobile nav. 44px touch targets. Disable heavy effects on mobile. Test 375px-1440px+.

### C11: PERFORMANCE AS DESIGN
GPU-only: transform, opacity, clip-path. CSS scroll-driven (off-thread). `content-visibility: auto`. Smart `will-change`. Speculation Rules API for instant loads. Font preload. WebP/AVIF.

### C12: THE INVISIBLE DETAILS
4/8px spacing scale. Section color transitions. Designed footer. `::selection` accent. `scrollbar-width: thin; scrollbar-color`. Font smoothing. `@scope`. `@layer`.

### C13: SVG FILTERS AS SECRET WEAPON
feTurbulence+feDisplacementMap liquid. feGaussianBlur+feColorMatrix gooey. Chromatic aberration. SVG line drawing (stroke-dashoffset). Shape morphing (MorphSVG/Flubber). SVG noise overlay. SMIL animation.

### C14: CINEMATIC TRANSITIONS & PRELOADERS
Clip-path/overlay/column page transitions. View Transitions API (MPA CSS-only). Barba.js (complex MPA). Speculation Rules + VT = instant animated nav. Branded preloaders with counter. sessionStorage first-visit detection.

### C15: KINETIC & REACTIVE TYPOGRAPHY
Mouse-repel letters. Text scramble/decode. Gooey SVG morphing. Wave per-character reveal. Variable font animation. Text along SVG path. Text mask video. Glitch pseudo-elements. Infinite marquee. CSS spring character animation.

### C16: ADVANCED SCROLL EXPERIENCES
Video scrub. Stacking sticky cards. Canvas image sequences. Spotlight cursor reveal. 3D CSS parallax (perspective+translateZ). Canvas animated grain. Scroll velocity effects.

### C17: CSS-NATIVE ANIMATION POWER
`animation-timeline: view()/scroll()`. `animation-range`. `@starting-style`. `transition-behavior: allow-discrete`. CSS `linear()` spring easing. `@property` gradient animation. `interpolate-size: allow-keywords`. Popover API animation. CSS Anchor Positioning.

### C18: ACCESSIBILITY AS NON-NEGOTIABLE
`prefers-reduced-motion: reduce` — disable/reduce ALL animations. `prefers-color-scheme`. 44px touch targets. `:focus-visible` outlines on everything. Semantic HTML. WCAG AA contrast. Skip-to-content link. `prefers-contrast`.

## Anti-Patterns (NEVER)
❌ Generic card grids with box shadows ❌ Purple→blue gradients ❌ Stock illustrations ❌ Symmetric everything ❌ `transition: all 0.3s ease` ❌ Font Awesome ❌ Cookie-cutter navbars ❌ Generic section titles ❌ Excessive border-radius ❌ Rainbow gradient text ❌ Competing simultaneous animations ❌ 3+ font families ❌ Pure #fff/#000 ❌ `outline: none` without replacement ❌ Missing prefers-reduced-motion ❌ Animating width/height/top/left ❌ `will-change` on everything ❌ Forgetting font-display: swap

## Output Checklist (ALL required)
- [ ] Hero = standalone visual statement
- [ ] Typography = 3-level hierarchy (OKLCH colors)
- [ ] 5+ distinct animation moments
- [ ] Custom easing (CSS linear() spring or cubic-bezier)
- [ ] Responsive 375px-1440px+
- [ ] Dark mode or intentional light reasoning
- [ ] 1+ "wow moment" (SVG filter, kinetic text, spotlight, transition)
- [ ] Designed footer
- [ ] 4/8px spacing scale
- [ ] No banned fonts/anti-patterns
- [ ] Preloader or entry sequence
- [ ] Hover states on ALL interactive elements
- [ ] `prefers-reduced-motion: reduce` present
- [ ] `:focus-visible` styles present
- [ ] Semantic HTML
- [ ] GPU-only animations (transform, opacity, clip-path)
- [ ] `content-visibility: auto` on heavy below-fold sections

## Technology Decision Table (2025-2026)
| Need | Best Tool |
|------|-----------|
| Smooth scroll | Lenis |
| Scroll animations | CSS scroll-driven + GSAP ScrollTrigger |
| Page transitions MPA | View Transitions API + Speculation Rules |
| Page transitions SPA | Motion AnimatePresence or GSAP |
| Complex MPA transitions | Barba.js + GSAP |
| Text animation | GSAP SplitText (free) |
| Spring easing | CSS linear() or JS Spring class |
| Gradient animation | CSS @property |
| Modal/popover animation | @starting-style + dialog/Popover API |
| 3D designer-friendly | Spline or model-viewer |
| 3D developer | Three.js or OGL |
| Image WebGL effects | Curtains.js or hover-effect |
| React animation | Motion (v11+) |
| Interactive animation | Rive |
| Pre-made animation | Lottie |

## Creative Variety (rotate, never repeat)
| Direction | Palette | Type | Motion |
|-----------|---------|------|--------|
| Brutalist Raw | Mono contrast | Mono+Grotesque | Instant snaps |
| Luxury Whisper | Creams/golds on dark | Serif+Thin Sans | Slow 1.2s+ |
| Neo-Geometric | Primary, sharp | Geo Sans+Mono | Precise |
| Organic Flow | Earth gradients | Humanist+Script | Spring physics |
| Retro-Digital | CRT greens, pixels | Pixel+Modern Sans | Glitch |
| Editorial Bold | Black+hot accent | Condensed+Serif | Scroll-snap |
| Playful Pop | Saturated multi | Rounded+Display | Bouncy |
| Minimal Void | Near-black+1 accent | Thin+Bold contrast | Barely-there |
| Glass & Light | Translucent layers | Variable weight | Glassmorphism |
| Cinematic Dark | Deep black+spot | Display serif+Mono | Film grain |

Studios charge $50K-$300K+ for this level. Match that energy.
