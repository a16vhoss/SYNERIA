# Advanced Animation Patterns Reference (Tier 2-4)

200+ "wow moment" techniques. Read when project needs that extra level of impact.

## Table of Contents
1. [SVG Filter Effects](#1)
2. [Text Morphing / Gooey](#2)
3. [Kinetic Typography (Full)](#3)
4. [Variable Font Animation](#4)
5. [Text Gradient Shimmer](#5)
6. [Text Mask with Video](#6)
7. [CSS Glitch Text](#7)
8. [Page Transitions](#8)
9. [Advanced Preloaders](#9)
10. [Image-on-Hover Navigation](#10)
11. [Spotlight / X-Ray Cursor](#11)
12. [Scroll-Driven Video](#12)
13. [Apple-Style Image Sequences](#13)
14. [Stacking Cards on Scroll](#14)
15. [Spring Physics Motion](#15)
16. [Canvas Animated Grain](#16)
17. [3D Parallax without Three.js](#17)
18. [Horizontal Scroll Sections](#18)
19. [Cursor Trail Effects](#19)
20. [Cursor Blob / Fluid](#20)
21. [Scroll Velocity Effects](#21)
22. [SVG Line Drawing](#22)
23. [SVG Shape Morphing](#23)
24. [Aurora / Northern Lights](#24)
25. [Ken Burns Effect](#25)
26. [Image Comparison Slider](#26)
27. [Dark Mode Circle Toggle](#27)
28. [Number Counter / Odometer](#28)
29. [Web Audio Hover Sounds](#29)
30. [Barba.js Page Transitions](#30)
31. [Speculation Rules API](#31)
32. [Spline 3D Integration](#32)
33. [Model-Viewer Web Component](#33)
34. [Advanced Hover Effects](#34)

---

## 1. SVG Filter Effects {#1}

```html
<svg style="position:absolute;width:0;height:0"><defs>
  <!-- Liquid Distortion -->
  <filter id="liquid"><feTurbulence type="fractalNoise" baseFrequency="0.015" numOctaves="3" result="n" seed="2"/><feDisplacementMap in="SourceGraphic" in2="n" scale="0" id="liqDisp" xChannelSelector="R" yChannelSelector="G"/></filter>
  <!-- Gooey Threshold -->
  <filter id="gooey"><feGaussianBlur in="SourceGraphic" stdDeviation="10" result="b"/><feColorMatrix in="b" type="matrix" values="1 0 0 0 0 0 1 0 0 0 0 0 1 0 0 0 0 0 255 -140"/></filter>
  <!-- Chromatic Aberration -->
  <filter id="chromatic"><feOffset in="SourceGraphic" dx="3" dy="0" result="r"/><feOffset in="SourceGraphic" dx="-3" dy="0" result="b"/><feColorMatrix in="r" type="matrix" values="1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0" result="ro"/><feColorMatrix in="b" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 1 0 0 0 0 0 1 0" result="bo"/><feMerge><feMergeNode in="ro"/><feMergeNode in="SourceGraphic"/><feMergeNode in="bo"/></feMerge></filter>
  <!-- Wavy (scroll-animated) -->
  <filter id="wavy"><feTurbulence type="turbulence" baseFrequency="0.02 0.06" numOctaves="2" result="t"/><feDisplacementMap in="SourceGraphic" in2="t" scale="0" id="wavyD" xChannelSelector="R" yChannelSelector="G"/></filter>
  <!-- Noise/Grain Overlay -->
  <filter id="noise"><feTurbulence type="fractalNoise" baseFrequency="0.65" numOctaves="3" stitchTiles="stitch"/></filter>
</defs></svg>
```

Animate displacement on hover:
```js
const disp = document.querySelector('#liqDisp');
el.addEventListener('mouseenter', () => gsap.to(disp, { attr: { scale: 30 }, duration: 0.6 }));
el.addEventListener('mouseleave', () => gsap.to(disp, { attr: { scale: 0 }, duration: 0.8 }));
```

## 2. Text Morphing / Gooey {#2}
SVG filter threshold + blur cycling between words. Full implementation:
```js
const texts = ['Word1', 'Word2', 'Word3'];
const el1 = document.querySelector('.morph-1'), el2 = document.querySelector('.morph-2');
let idx = 0, morph = 0, cool = 2.5, time = new Date();
function doMorph() { morph -= (new Date() - time) / 1000 * 0.4; time = new Date(); let f = Math.min(morph, 1); if (f <= 0) { cool = 2.5; idx++; return; }
  el2.style.filter = `blur(${Math.min(8/f-8,100)}px)`; el2.style.opacity = `${Math.pow(f,0.4)*100}%`;
  f = 1-f; el1.style.filter = `blur(${Math.min(8/f-8,100)}px)`; el1.style.opacity = `${Math.pow(f,0.4)*100}%`; }
function doCool() { morph=0; el2.style.filter=''; el2.style.opacity='100%'; el1.style.filter=''; el1.style.opacity='0%'; }
function loop() { requestAnimationFrame(loop); let dt=(new Date()-time)/1000; time=new Date(); cool-=dt;
  if(cool<=0){if(cool>=-dt){el1.textContent=texts[idx%texts.length];el2.textContent=texts[(idx+1)%texts.length]}doMorph()}else doCool() }
loop();
```
Wrap container in `filter: url(#gooey)`.

## 3. Kinetic Typography {#3}

### Mouse-Repel Letters
```js
class RepelText {
  constructor(el, radius=100, strength=30) { this.el=el; this.r=radius; this.s=strength; this.chars=[]; this.mouse={x:-1e3,y:-1e3};
    el.innerHTML=''; [...el.textContent].forEach(c => { const s=document.createElement('span'); s.textContent=c===' '?'\u00A0':c; s.style.cssText='display:inline-block;transition:transform 0.4s cubic-bezier(0.16,1,0.3,1)'; el.appendChild(s); this.chars.push(s); });
    window.addEventListener('mousemove', e => { this.mouse={x:e.clientX,y:e.clientY}; this.update(); }); }
  update() { this.chars.forEach(c => { const r=c.getBoundingClientRect(), cx=r.left+r.width/2, cy=r.top+r.height/2, dx=cx-this.mouse.x, dy=cy-this.mouse.y, d=Math.hypot(dx,dy);
    if(d<this.r){const f=(1-d/this.r)*this.s,a=Math.atan2(dy,dx);c.style.transform=`translate(${Math.cos(a)*f}px,${Math.sin(a)*f}px)`}else c.style.transform='translate(0,0)' }); }
}
```

### Wave Character Reveal
```css
.wave-text.revealed span { animation: wave 0.6s cubic-bezier(0.16,1,0.3,1) forwards; animation-delay: calc(var(--i)*0.025s); opacity:0; transform:translateY(80px) rotateX(90deg); }
@keyframes wave { to { opacity:1; transform:translateY(0) rotateX(0); } }
```

### Text Scramble (Full)
```js
class TextScramble {
  constructor(el){this.el=el;this.og=el.textContent;this.ch='!<>-_\\/[]{}—=+*^?#';this.q=[];this.f=0;this.raf=0}
  run(){const l=this.og.length;this.q=[];for(let i=0;i<l;i++){const s=~~(Math.random()*12),e=s+~~(Math.random()*12);this.q.push({to:this.og[i],s,e,c:''})}this.f=0;this.step()}
  step(){let o='',d=0;for(let i=0;i<this.q.length;i++){let{to,s,e,c}=this.q[i];if(this.f>=e){d++;o+=to}else if(this.f>=s){if(!c||Math.random()<0.3){c=this.ch[~~(Math.random()*this.ch.length)];this.q[i].c=c}o+=c}else o+=to}
  this.el.textContent=o;if(d<this.q.length){this.f++;this.raf=requestAnimationFrame(()=>this.step())}}
  reset(){cancelAnimationFrame(this.raf);this.el.textContent=this.og}
}
```

## 4. Variable Font Animation {#4}
```css
@font-face { font-family: 'Fraunces'; src: url('...') format('woff2'); font-weight: 100 900; font-style: normal; }
.var-font-hover { font-family: 'Fraunces'; font-variation-settings: 'wght' 400, 'SOFT' 0; transition: font-variation-settings 0.4s cubic-bezier(0.16,1,0.3,1); }
.var-font-hover:hover { font-variation-settings: 'wght' 900, 'SOFT' 100; }
```
Per-character with Splitting.js: set `--char-index` CSS variable, use `animation-delay: calc(var(--char-index) * 0.05s)`.

## 5. Text Gradient Shimmer {#5}
```css
.shimmer { background: linear-gradient(120deg, var(--text) 40%, var(--accent) 50%, var(--text) 60%); background-size: 300% 100%; -webkit-background-clip: text; -webkit-text-fill-color: transparent; animation: shimmerMove 3s ease-in-out infinite; }
@keyframes shimmerMove { 0%{background-position:100% 0} 100%{background-position:-100% 0} }
```

## 6. Text Mask with Video {#6}
```css
.text-mask-container { position: relative; }
.text-mask-container video { width:100%; height:100%; object-fit:cover; }
.text-mask-overlay { position:absolute; inset:0; background:#0a0a0a; mix-blend-mode:multiply; display:grid; place-items:center; }
.text-mask-overlay h1 { font-size:clamp(4rem,15vw,12rem); color:#fff; font-family:var(--font-d); }
```

## 7. CSS Glitch Text {#7}
```css
.glitch { position:relative; font-family:var(--font-d); font-size:clamp(3rem,8vw,6rem); }
.glitch::before, .glitch::after { content:attr(data-text); position:absolute; inset:0; }
.glitch::before { color:cyan; animation:glitchTop 2s infinite; clip-path:inset(0 0 60% 0); }
.glitch::after { color:magenta; animation:glitchBottom 2s infinite 0.1s; clip-path:inset(60% 0 0 0); }
@keyframes glitchTop { 2%{transform:translate(2px,-2px)} 4%{transform:translate(-2px,2px)} 6%,100%{transform:translate(0)} }
@keyframes glitchBottom { 2%{transform:translate(-2px,2px)} 4%{transform:translate(2px,-2px)} 6%,100%{transform:translate(0)} }
```

## 8. Page Transitions {#8}
### Clip-Path Circle Wipe
```css
.page-transition { position:fixed; inset:0; background:var(--bg); z-index:9999; clip-path:circle(0% at 50% 50%); pointer-events:none; transition:clip-path 0.9s cubic-bezier(0.76,0,0.24,1); }
.page-transition.active { clip-path:circle(150% at 50% 50%); }
```
### Multi-Column Stagger
```css
.col-wipe { position:fixed; inset:0; z-index:9999; display:flex; pointer-events:none; }
.col-wipe__bar { flex:1; background:var(--bg); transform:scaleY(0); transform-origin:top; transition:transform 0.5s cubic-bezier(0.76,0,0.24,1); }
.col-wipe.active .col-wipe__bar { transform:scaleY(1); }
.col-wipe.active .col-wipe__bar:nth-child(1){transition-delay:0s}
.col-wipe.active .col-wipe__bar:nth-child(2){transition-delay:0.06s}
.col-wipe.active .col-wipe__bar:nth-child(3){transition-delay:0.12s}
.col-wipe.active .col-wipe__bar:nth-child(4){transition-delay:0.18s}
.col-wipe.active .col-wipe__bar:nth-child(5){transition-delay:0.24s}
```

## 9. Advanced Preloaders {#9}
```js
let prog=0; const counter=document.getElementById('count'), fill=document.getElementById('fill'), pre=document.getElementById('pre');
function load(){if(prog<100){prog+=Math.random()*15+3;if(prog>100)prog=100; counter.textContent=Math.floor(prog); fill.style.width=prog+'%';
setTimeout(load,60+Math.random()*100)}else setTimeout(()=>{pre.classList.add('done');document.body.style.overflow=''},300)}
document.body.style.overflow='hidden'; load();
```
First-visit detection: `if(!sessionStorage.getItem('visited')){sessionStorage.setItem('visited','1'); /* show preloader */}`

## 10. Image-on-Hover Navigation {#10}
```js
const bg=document.getElementById('navBg');
document.querySelectorAll('.imgnav__link').forEach(l=>{
  l.addEventListener('mouseenter',()=>{bg.style.backgroundImage=`url(${l.dataset.img})`;bg.classList.add('visible')});
  l.addEventListener('mouseleave',()=>bg.classList.remove('visible'));});
```
```css
.imgnav__bg { position:fixed; inset:0; z-index:-1; background-size:cover; background-position:center; opacity:0; transform:scale(1.1); transition:opacity 0.5s, transform 0.8s cubic-bezier(0.16,1,0.3,1); filter:brightness(0.25); }
.imgnav__bg.visible { opacity:1; transform:scale(1); }
.imgnav:hover .imgnav__link { opacity:0.2; }
.imgnav__link:hover { opacity:1!important; transform:translateX(20px); }
```

## 11. Spotlight / X-Ray Cursor {#11}
```js
const hidden=document.querySelector('.spot-hidden'), section=document.querySelector('.spot');
section.addEventListener('mousemove', e => { const r=section.getBoundingClientRect(); hidden.style.clipPath=`circle(140px at ${e.clientX-r.left}px ${e.clientY-r.top}px)`; });
section.addEventListener('mouseleave', () => { hidden.style.clipPath='circle(0px at 50% 50%)'; });
```

## 12. Scroll-Driven Video {#12}
```js
const video=document.getElementById('scrubVideo'), section=document.querySelector('.video-scrub');
video.pause();
window.addEventListener('scroll',()=>{const r=section.getBoundingClientRect(),p=Math.max(0,Math.min(1,-r.top/(section.offsetHeight-innerHeight)));if(video.duration)video.currentTime=p*video.duration});
```
```css
.video-scrub { height:500vh; position:relative; }
.video-scrub video { position:sticky; top:0; width:100%; height:100vh; object-fit:cover; }
```

## 13. Apple-Style Image Sequences {#13}
```js
const canvas=document.getElementById('seqCanvas'), ctx=canvas.getContext('2d'), frameCount=120, frames=[];
canvas.width=1920; canvas.height=1080;
for(let i=0;i<frameCount;i++){const img=new Image();img.src=`/frames/frame_${String(i).padStart(4,'0')}.webp`;frames.push(img)}
frames[0].onload=()=>ctx.drawImage(frames[0],0,0);
window.addEventListener('scroll',()=>{const p=window.scrollY/(document.body.scrollHeight-innerHeight);const idx=Math.min(frameCount-1,Math.floor(p*frameCount));ctx.clearRect(0,0,canvas.width,canvas.height);if(frames[idx].complete)ctx.drawImage(frames[idx],0,0)});
```
```css
#seqCanvas { position:fixed; top:0; left:0; width:100%; height:100vh; object-fit:cover; z-index:-1; }
```

## 14. Stacking Cards {#14}
```css
.stack-card { position:sticky; top:12vh; margin-bottom:-55vh; padding:48px; background:var(--bg3); border:1px solid var(--border); border-radius:20px; min-height:65vh; transform-origin:center top; }
.stack-card:nth-child(1){z-index:5}
.stack-card:nth-child(2){z-index:4;top:calc(12vh+32px)}
.stack-card:nth-child(3){z-index:3;top:calc(12vh+64px)}
```
```js
document.querySelectorAll('.stack-card').forEach(c=>{window.addEventListener('scroll',()=>{const r=c.getBoundingClientRect();if(r.top<innerHeight*0.15){const s=Math.max(0.92,1-(innerHeight*0.15-r.top)*0.0002);c.style.transform=`scale(${s})`;c.style.opacity=Math.max(0.65,s)}else{c.style.transform='scale(1)';c.style.opacity='1'}})});
```

## 15. Spring Physics {#15}
```js
class Spring {
  constructor({stiffness=0.15,damping=0.8,mass=1}={}){this.s=stiffness;this.d=damping;this.m=mass;this.v=0;this.val=0;this.target=0}
  update(){const f=(this.target-this.val)*this.s;this.v=(this.v+f/this.m)*this.d;this.val+=this.v;return this.val}
  settled(){return Math.abs(this.v)<0.001&&Math.abs(this.target-this.val)<0.001}
}
```

## 16. Canvas Animated Grain {#16}
```js
const gc=document.getElementById('grain'),gx=gc.getContext('2d');
function gResize(){gc.width=innerWidth/3;gc.height=innerHeight/3}gResize();window.addEventListener('resize',gResize);
(function renderGrain(){const w=gc.width,h=gc.height,d=gx.createImageData(w,h),p=d.data;for(let i=0;i<p.length;i+=4){const v=Math.random()*255;p[i]=v;p[i+1]=v;p[i+2]=v;p[i+3]=255}gx.putImageData(d,0,0);requestAnimationFrame(renderGrain)})();
```
```css
.grain-canvas { position:fixed; inset:0; width:100%; height:100%; pointer-events:none; z-index:9998; opacity:0.035; mix-blend-mode:overlay; }
```

## 17. 3D Parallax without Three.js {#17}
### Mouse-Driven Tilt + Glare
```js
document.querySelectorAll('.tilt-card').forEach(card=>{
  const glare=card.querySelector('.glare');
  card.addEventListener('mousemove',e=>{const r=card.getBoundingClientRect(),x=(e.clientX-r.left)/r.width,y=(e.clientY-r.top)/r.height;
    card.style.transform=`perspective(700px) rotateY(${(x-0.5)*10}deg) rotateX(${(0.5-y)*10}deg)`;
    if(glare)glare.style.background=`radial-gradient(circle at ${x*100}% ${y*100}%,rgba(255,255,255,0.12),transparent 60%)`});
  card.addEventListener('mouseleave',()=>{card.style.transform='';card.style.transition='transform 0.6s cubic-bezier(0.16,1,0.3,1)';if(glare)glare.style.background='transparent'});
  card.addEventListener('mouseenter',()=>{card.style.transition='none'})});
```

## 18. Horizontal Scroll {#18}
GSAP: see PATTERNS.md Section 11. CSS-only:
```css
.h-scroll { display:flex; overflow-x:auto; scroll-snap-type:x mandatory; -webkit-overflow-scrolling:touch; scrollbar-width:none; }
.h-scroll::-webkit-scrollbar{display:none}
.h-scroll__item { flex:0 0 min(450px,85vw); scroll-snap-align:center; margin-right:24px; }
```

## 19. Cursor Trail Effects {#19}
### Fading Dot Trail
```js
const trail=[]; const TRAIL_LEN=12;
for(let i=0;i<TRAIL_LEN;i++){const d=document.createElement('div');d.style.cssText=`position:fixed;width:${8-i*0.5}px;height:${8-i*0.5}px;border-radius:50%;background:rgba(255,255,255,${1-i/TRAIL_LEN});pointer-events:none;z-index:9999;transition:transform 0.05s`;document.body.appendChild(d);trail.push({el:d,x:0,y:0})}
document.addEventListener('mousemove',e=>{trail[0].x=e.clientX;trail[0].y=e.clientY});
(function animate(){for(let i=trail.length-1;i>0;i--){trail[i].x+=(trail[i-1].x-trail[i].x)*0.3;trail[i].y+=(trail[i-1].y-trail[i].y)*0.3}trail.forEach(t=>t.el.style.transform=`translate(${t.x-4}px,${t.y-4}px)`);requestAnimationFrame(animate)})();
```

## 20. Cursor Blob / Fluid {#20}
```css
.blob-cursor { position:fixed; width:40px; height:40px; background:var(--accent); border-radius:50%; pointer-events:none; z-index:10000; mix-blend-mode:difference; filter:url(#gooey);
  animation:blobMorph 4s ease-in-out infinite; }
@keyframes blobMorph { 0%,100%{border-radius:50%} 25%{border-radius:40% 60% 50% 70%} 50%{border-radius:60% 40% 70% 30%} 75%{border-radius:30% 70% 40% 60%} }
```

## 21. Scroll Velocity Effects {#21}
```js
// With GSAP ScrollTrigger
ScrollTrigger.create({ onUpdate: self => {
  const v = self.getVelocity();
  const skew = Math.min(Math.abs(v) * 0.002, 8) * Math.sign(v);
  gsap.to('.velocity-target', { skewY: skew, duration: 0.3, ease: 'power2.out' });
}});
// Reset on idle
gsap.to('.velocity-target', { skewY: 0, duration: 0.8, ease: 'elastic.out(1, 0.3)', scrollTrigger: { onLeave: () => {} } });
```

## 22. SVG Line Drawing {#22}
```css
.svg-draw path { stroke-dasharray: 1; stroke-dashoffset: 1; fill: none; stroke: var(--text); stroke-width: 2; }
.svg-draw.revealed path { transition: stroke-dashoffset 2s cubic-bezier(0.76, 0, 0.24, 1); stroke-dashoffset: 0; }
```
Use `pathLength="1"` attribute on SVG paths to normalize length.

## 23. SVG Shape Morphing {#23}
With GSAP MorphSVG (free):
```js
gsap.to('#shape', { morphSVG: '#targetShape', duration: 1.2, ease: 'power2.inOut' });
```
With Flubber.js (MIT):
```js
import { interpolate } from 'flubber';
const interp = interpolate(startPathD, endPathD);
gsap.to({t:0}, {t:1, duration:1, onUpdate:function(){ path.setAttribute('d', interp(this.targets()[0].t)) }});
```

## 24. Aurora / Northern Lights {#24}
```css
.aurora { background: var(--bg); position: relative; overflow: hidden; }
.aurora::before { content:''; position:absolute; inset:-50%; width:200%; height:200%;
  background: conic-gradient(from var(--aurora-angle, 0deg), oklch(0.5 0.2 280 / 0.15), oklch(0.6 0.2 150 / 0.1), oklch(0.5 0.15 25 / 0.12), transparent 60%);
  animation: auroraRotate 8s linear infinite; filter: blur(60px); }
@property --aurora-angle { syntax: '<angle>'; initial-value: 0deg; inherits: false; }
@keyframes auroraRotate { to { --aurora-angle: 360deg; } }
```

## 25. Ken Burns Effect {#25}
```css
.kenburns img { animation: kenburns 20s ease-in-out infinite alternate; }
@keyframes kenburns { from { transform: scale(1) translate(0,0); } to { transform: scale(1.3) translate(-100px,-50px); } }
```

## 26. Image Comparison Slider {#26}
```html
<div class="compare" style="--pos:50%">
  <img class="compare__before" src="before.jpg">
  <img class="compare__after" src="after.jpg" style="clip-path:inset(0 0 0 var(--pos))">
  <input type="range" min="0" max="100" value="50" oninput="this.parentElement.style.setProperty('--pos',this.value+'%')">
</div>
```

## 27. Dark Mode Circle Toggle {#27}
```js
function toggleDark(event) {
  const x=event.clientX, y=event.clientY;
  if(!document.startViewTransition){document.documentElement.classList.toggle('dark');return}
  const transition = document.startViewTransition(() => document.documentElement.classList.toggle('dark'));
  transition.ready.then(() => {
    const max = Math.hypot(Math.max(x,innerWidth-x), Math.max(y,innerHeight-y));
    document.documentElement.animate({clipPath:[`circle(0px at ${x}px ${y}px)`,`circle(${max}px at ${x}px ${y}px)`]},{duration:500,easing:'cubic-bezier(0.76,0,0.24,1)',pseudoElement:'::view-transition-new(root)'});
  });
}
```

## 28. Number Counter / Odometer {#28}
```js
function countUp(el, target, duration=2000) {
  let start=0; const startTime=performance.now();
  function update(now) { const p=Math.min((now-startTime)/duration,1); el.textContent=Math.floor(p*target);
    if(p<1)requestAnimationFrame(update); else el.textContent=target; }
  requestAnimationFrame(update);
}
// Trigger with IntersectionObserver
```

## 29. Web Audio Hover Sounds {#29}
```js
let audioCtx;
function playHoverSound() {
  if(!audioCtx) audioCtx = new (window.AudioContext || window.webkitAudioContext)();
  const osc=audioCtx.createOscillator(), gain=audioCtx.createGain();
  osc.connect(gain); gain.connect(audioCtx.destination);
  osc.frequency.value=800+Math.random()*400; osc.type='sine';
  gain.gain.setValueAtTime(0.05,audioCtx.currentTime);
  gain.gain.exponentialRampToValueAtTime(0.001,audioCtx.currentTime+0.15);
  osc.start(); osc.stop(audioCtx.currentTime+0.15);
}
document.querySelectorAll('[data-sound]').forEach(el=>el.addEventListener('mouseenter',playHoverSound));
```

## 30. Barba.js Page Transitions {#30}
```html
<script src="https://cdn.jsdelivr.net/npm/@barba/core"></script>
```
```js
barba.init({
  transitions: [{
    leave(data) { return gsap.to(data.current.container, { opacity: 0, y: -20, duration: 0.5 }); },
    enter(data) { return gsap.from(data.next.container, { opacity: 0, y: 20, duration: 0.5 }); }
  }]
});
```

## 31. Speculation Rules API {#31}
Instant page loads by prefetching/prerendering on hover:
```html
<script type="speculationrules">
{ "prerender": [{ "where": { "href_matches": "/*" }, "eagerness": "moderate" }] }
</script>
```
`moderate` = prerender on hover. Combine with View Transitions API for instant animated navigation.

## 32. Spline 3D Integration {#32}
```html
<script type="module" src="https://unpkg.com/@splinetool/viewer/build/spline-viewer.js"></script>
<spline-viewer url="https://prod.spline.design/YOUR_SCENE/scene.splinecode" loading-anim-type="spinner-small-dark"></spline-viewer>
```

## 33. Model-Viewer Web Component {#33}
```html
<script type="module" src="https://ajax.googleapis.com/ajax/libs/model-viewer/3.4.0/model-viewer.min.js"></script>
<model-viewer src="product.glb" alt="3D Product" auto-rotate camera-controls shadow-intensity="1" ar></model-viewer>
```

## 34. Advanced Hover Effects {#34}
### Tilt + Glare (see Section 17)
### Background Section Color Shift
```css
.color-shift { transition: background 0.8s cubic-bezier(0.16,1,0.3,1); }
.color-shift[data-color="red"]:hover { background: oklch(0.15 0.05 25); }
```
### Hover Image Reveal (floating)
```js
const reveal=document.querySelector('.hover-reveal'), revealImg=reveal.querySelector('img');
document.querySelectorAll('[data-reveal-img]').forEach(link=>{
  link.addEventListener('mouseenter',()=>{revealImg.src=link.dataset.revealImg;reveal.classList.add('visible')});
  link.addEventListener('mousemove',e=>{reveal.style.left=e.clientX+20+'px';reveal.style.top=e.clientY-200+'px'});
  link.addEventListener('mouseleave',()=>reveal.classList.remove('visible'))});
```
```css
.hover-reveal { position:fixed; width:300px; height:400px; pointer-events:none; z-index:50; overflow:hidden; border-radius:12px;
  clip-path:inset(100% 0 0 0); transition:clip-path 0.4s cubic-bezier(0.76,0,0.24,1); }
.hover-reveal.visible { clip-path:inset(0); }
```

---

### Accessibility Reminder
EVERY technique in this file should be wrapped in `@media (prefers-reduced-motion: no-preference)` or have a reduced-motion fallback. Canvas grain, cursor effects, and heavy animations should be disabled entirely under `prefers-reduced-motion: reduce`. Always provide `:focus-visible` styles alongside hover effects.
