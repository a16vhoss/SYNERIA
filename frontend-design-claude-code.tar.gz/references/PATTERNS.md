# Core Frontend Patterns Reference (Tier 0-2)

## Table of Contents
1. [Entry Animations](#1-entry-animations)
2. [Scroll Mechanics](#2-scroll-mechanics)
3. [Custom Cursor System](#3-custom-cursor)
4. [Typography Animation](#4-typography-animation)
5. [Image Reveal Effects](#5-image-reveals)
6. [Navigation Patterns](#6-navigation)
7. [Button & CTA Patterns](#7-buttons)
8. [Layout Compositions](#8-layouts)
9. [Color Systems](#9-color-systems)
10. [Font Pairings Library](#10-font-pairings)
11. [GSAP ScrollTrigger Recipes](#11-gsap-recipes)
12. [Three.js Starter Patterns](#12-threejs)
13. [CSS-Only Effects Library](#13-css-effects)
14. [CSS-Native Animation Power (2025-2026)](#14-css-native)
15. [Performance Checklist](#15-performance)

---

## 1. Entry Animations

### Staggered Hero Reveal (CSS-only)
```css
.hero-line { overflow: hidden; }
.hero-line span {
  display: inline-block;
  transform: translateY(110%);
  animation: revealUp 0.9s cubic-bezier(0.76, 0, 0.24, 1) forwards;
}
.hero-line:nth-child(2) span { animation-delay: 0.1s; }
.hero-line:nth-child(3) span { animation-delay: 0.2s; }
@keyframes revealUp { to { transform: translateY(0); } }
```

### Clip-Path Reveal
```css
.reveal-element {
  clip-path: inset(0 0 100% 0);
  animation: clipReveal 1s cubic-bezier(0.76, 0, 0.24, 1) 0.3s forwards;
}
@keyframes clipReveal { to { clip-path: inset(0 0 0% 0); } }
```

### Scale + Fade (Luxury style)
```css
.hero-media {
  opacity: 0; transform: scale(1.1);
  animation: mediaReveal 1.4s cubic-bezier(0.16, 1, 0.3, 1) 0.2s forwards;
}
@keyframes mediaReveal { to { opacity: 1; transform: scale(1); } }
```

### Preloader → Content
```css
.preloader {
  position: fixed; inset: 0; z-index: 9999;
  background: var(--bg); display: grid; place-items: center;
}
.preloader.done { animation: preloaderExit 0.8s cubic-bezier(0.76, 0, 0.24, 1) forwards; }
@keyframes preloaderExit { to { clip-path: inset(0 0 100% 0); } }
```

---

## 2. Scroll Mechanics

### Lenis Smooth Scroll (CDN)
```html
<script src="https://cdn.jsdelivr.net/npm/lenis@latest/dist/lenis.min.js"></script>
```
```js
const lenis = new Lenis({ duration: 1.2, easing: (t) => Math.min(1, 1.001 - Math.pow(2, -10 * t)), smoothWheel: true });
function raf(time) { lenis.raf(time); requestAnimationFrame(raf); }
requestAnimationFrame(raf);
```

### Scroll Reveals (IntersectionObserver fallback)
```js
const observer = new IntersectionObserver((entries) => {
  entries.forEach(entry => { if (entry.isIntersecting) { entry.target.classList.add('revealed'); observer.unobserve(entry.target); } });
}, { threshold: 0.15, rootMargin: '0px 0px -50px 0px' });
document.querySelectorAll('[data-reveal]').forEach(el => observer.observe(el));
```
```css
[data-reveal] { opacity: 0; transform: translateY(40px); transition: opacity 0.8s cubic-bezier(0.76, 0, 0.24, 1), transform 0.8s cubic-bezier(0.76, 0, 0.24, 1); }
[data-reveal].revealed { opacity: 1; transform: translateY(0); }
```

### CSS Scroll-Driven Reveal (Tier 0 — PREFERRED)
```css
[data-reveal-css] {
  animation: cssReveal linear both;
  animation-timeline: view();
  animation-range: entry 0% cover 30%;
}
@keyframes cssReveal {
  from { opacity: 0; transform: translateY(50px); }
  to { opacity: 1; transform: translateY(0); }
}
```

---

## 3. Custom Cursor System

### Spring Physics Cursor
```js
class Spring {
  constructor(s = 0.08, d = 0.82) { this.s = s; this.d = d; this.v = 0; this.val = 0; this.target = 0; }
  update() { this.v = (this.v + (this.target - this.val) * this.s) * this.d; this.val += this.v; return this.val; }
}
const cur = document.querySelector('.cursor'), dot = document.querySelector('.cursor-dot');
const sx = new Spring(0.07, 0.82), sy = new Spring(0.07, 0.82);
let mx = 0, my = 0;
document.addEventListener('mousemove', e => { mx = e.clientX; my = e.clientY; dot.style.transform = `translate(${mx - 3}px, ${my - 3}px)`; });
function animate() { sx.target = mx; sy.target = my; cur.style.transform = `translate(${sx.update() - 10}px, ${sy.update() - 10}px)`; requestAnimationFrame(animate); }
animate();
```

### Cursor CSS
```css
.cursor, .cursor-dot { position: fixed; top: 0; left: 0; pointer-events: none; z-index: 10000; border-radius: 50%; mix-blend-mode: difference; }
.cursor { width: 20px; height: 20px; border: 1.5px solid rgba(255,255,255,0.5); transition: width 0.35s cubic-bezier(0.16,1,0.3,1), height 0.35s cubic-bezier(0.16,1,0.3,1); }
.cursor.hover { width: 60px; height: 60px; border-color: var(--accent); }
.cursor-dot { width: 6px; height: 6px; background: #fff; }
@media (hover: none) { .cursor, .cursor-dot { display: none; } body { cursor: auto; } }
```

### Magnetic Buttons
```js
document.querySelectorAll('[data-magnetic]').forEach(btn => {
  btn.addEventListener('mousemove', e => { const r = btn.getBoundingClientRect(); btn.style.transform = `translate(${(e.clientX - r.left - r.width/2) * 0.3}px, ${(e.clientY - r.top - r.height/2) * 0.3}px)`; });
  btn.addEventListener('mouseleave', () => { btn.style.transform = ''; btn.style.transition = 'transform 0.5s cubic-bezier(0.16,1,0.3,1)'; });
  btn.addEventListener('mouseenter', () => { btn.style.transition = 'none'; });
});
```

---

## 4. Typography Animation

### Text Split + Stagger Reveal
```js
function splitText(el) {
  const text = el.textContent; el.innerHTML = '';
  [...text].forEach((char, i) => { const s = document.createElement('span'); s.textContent = char === ' ' ? '\u00A0' : char; s.style.cssText = `display:inline-block;animation-delay:${i*0.03}s`; el.appendChild(s); });
}
```

### Text Scramble on Hover
```js
class TextScramble {
  constructor(el) { this.el = el; this.original = el.textContent; this.chars = '!<>-_\\/[]{}—=+*^?#'; }
  scramble() { /* see ADVANCED.md for full implementation */ }
}
```

### Infinite Marquee (Accessible)
```html
<div class="marquee" role="marquee"><div class="marquee__track">
  <div class="marquee__content"><!-- items --></div>
  <div class="marquee__content" aria-hidden="true"><!-- duplicate --></div>
</div></div>
```
```css
.marquee { overflow: hidden; }
.marquee__track { display: flex; width: max-content; animation: scroll 25s linear infinite; }
@keyframes scroll { to { transform: translateX(-50%); } }
@media (prefers-reduced-motion: reduce) { .marquee__track { animation: none; } }
```

---

## 5. Image Reveal Effects

### Clip-Path Wipe
```css
.img-reveal { clip-path: polygon(0 0, 0 0, 0 100%, 0 100%); transition: clip-path 1s cubic-bezier(0.76, 0, 0.24, 1); }
.img-reveal.revealed { clip-path: polygon(0 0, 100% 0, 100% 100%, 0 100%); }
```

### Scale-Down Overflow
```css
.img-container { overflow: hidden; border-radius: 12px; }
.img-container img { transform: scale(1.3); transition: transform 1.2s cubic-bezier(0.16, 1, 0.3, 1); }
.img-container.revealed img { transform: scale(1); }
```

### Hover Zoom
```css
.img-hover { overflow: hidden; border-radius: 12px; }
.img-hover img { transition: transform 0.6s cubic-bezier(0.16, 1, 0.3, 1); }
.img-hover:hover img { transform: scale(1.06); }
```

---

## 6. Navigation Patterns

### Transparent → Solid on Scroll
```css
.nav { position: fixed; top: 0; left: 0; right: 0; z-index: 100; padding: 20px 40px; transition: background 0.4s, backdrop-filter 0.4s; }
.nav.scrolled { background: rgba(10, 10, 10, 0.8); backdrop-filter: blur(20px); padding: 12px 40px; }
```

### Full-Screen Menu Overlay
```css
.menu-overlay { position: fixed; inset: 0; background: var(--bg); z-index: 200; clip-path: circle(0% at calc(100% - 40px) 40px); transition: clip-path 0.8s cubic-bezier(0.76, 0, 0.24, 1); }
.menu-overlay.open { clip-path: circle(150% at calc(100% - 40px) 40px); }
.menu-overlay a { font-size: clamp(2rem, 6vw, 5rem); opacity: 0; transform: translateY(30px); }
.menu-overlay.open a { opacity: 1; transform: translateY(0); transition: all 0.5s; transition-delay: calc(var(--i) * 0.08s + 0.3s); }
```

---

## 7. Button & CTA Patterns

### Fill-on-Hover
```css
.btn-fill { position: relative; padding: 16px 40px; border: 1px solid currentColor; background: transparent; overflow: hidden; cursor: pointer; font-size: 14px; letter-spacing: 0.05em; text-transform: uppercase; }
.btn-fill::before { content: ''; position: absolute; inset: 0; background: var(--text); transform: scaleX(0); transform-origin: left; transition: transform 0.5s cubic-bezier(0.76, 0, 0.24, 1); z-index: -1; }
.btn-fill:hover::before { transform: scaleX(1); }
.btn-fill:hover { color: var(--bg); }
```

### Animated Underline Link
```css
.link-underline { position: relative; }
.link-underline::after { content: ''; position: absolute; bottom: -2px; left: 0; width: 100%; height: 1px; background: currentColor; transform: scaleX(0); transform-origin: right; transition: transform 0.4s cubic-bezier(0.76, 0, 0.24, 1); }
.link-underline:hover::after { transform: scaleX(1); transform-origin: left; }
```

---

## 8. Layout Compositions

### Staggered Project Grid
```css
.project-grid { display: grid; grid-template-columns: repeat(12, 1fr); gap: 24px; padding: 0 5vw; }
.project-grid .item:nth-child(odd) { grid-column: 1 / 7; }
.project-grid .item:nth-child(even) { grid-column: 7 / 13; margin-top: 15vh; }
```

### Bento Grid
```css
.bento { display: grid; grid-template-columns: repeat(4, 1fr); grid-auto-rows: minmax(200px, auto); gap: 16px; grid-auto-flow: dense; }
.bento .wide { grid-column: span 2; }
.bento .tall { grid-row: span 2; }
.bento .big { grid-column: span 2; grid-row: span 2; }
```

---

## 9. Color Systems

### OKLCH-Based Dark (PREFERRED 2025+)
```css
:root {
  color-scheme: light dark;
  --bg: oklch(0.1 0 0);
  --bg2: oklch(0.13 0 0);
  --text: oklch(0.9 0 0);
  --muted: oklch(0.5 0 0);
  --accent: oklch(0.65 0.25 25); /* vibrant red */
  --accent-soft: color-mix(in oklch, var(--accent) 20%, transparent);
  --surface: oklch(0.15 0 0);
  --border: oklch(0.2 0 0 / 0.5);
}
```

### Hex Dark Luxury (Broader Support Fallback)
```css
:root { --bg:#0a0a0a; --bg2:#141414; --text:#e5e5e5; --muted:#888; --accent:#e10600; --surface:#1a1a1a; --border:rgba(255,255,255,0.06); }
```

### light-dark() Usage
```css
:root { color-scheme: light dark; }
body { background: light-dark(#faf8f5, #0a0a0a); color: light-dark(#1a1a1a, #e5e5e5); }
```

---

## 10. Font Pairings Library

| Headline | Body | Vibe |
|----------|------|------|
| Playfair Display | DM Sans | Classic Luxury |
| Clash Display | Satoshi | Bold Futurism |
| Instrument Serif | Instrument Sans | Contemporary |
| Cabinet Grotesk | General Sans | Bold Agency |
| DM Serif Display | Manrope | Warm Authority |
| Cormorant Garamond | Nunito Sans | Editorial |
| Syne | General Sans | Tech-Forward |
| Fraunces (variable) | Work Sans | Organic Premium |
| Bebas Neue | Source Sans 3 | Condensed Impact |
| Noto Serif Display | Noto Sans | Global-Ready |

```html
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=HEADLINE:wght@400;700&family=BODY:wght@300;400;500&display=swap" rel="stylesheet">
```

---

## 11. GSAP ScrollTrigger Recipes

### CDN
```html
<script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.5/gsap.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.5/ScrollTrigger.min.js"></script>
```

### Basic Reveal
```js
gsap.registerPlugin(ScrollTrigger);
gsap.utils.toArray('[data-gsap]').forEach(el => {
  gsap.from(el, { y: 60, opacity: 0, duration: 1, ease: 'power3.out', scrollTrigger: { trigger: el, start: 'top 85%' } });
});
```

### Pinned Section Scrub
```js
gsap.timeline({ scrollTrigger: { trigger: '.pin', start: 'top top', end: '+=200%', pin: true, scrub: 1, anticipatePin: 1 } })
  .from('.step-1', { opacity: 0, y: 50 }).to('.step-1', { opacity: 0, y: -50 })
  .from('.step-2', { opacity: 0, y: 50 });
```

### Horizontal Scroll
```js
const panels = gsap.utils.toArray('.h-panel');
gsap.to(panels, { xPercent: -100 * (panels.length - 1), ease: 'none',
  scrollTrigger: { trigger: '.h-container', pin: true, scrub: 1, snap: 1 / (panels.length - 1), end: () => '+=' + document.querySelector('.h-container').scrollWidth }
});
```

---

## 12. Three.js Starter

### Minimal Responsive Scene
```js
import * as THREE from 'three';
const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(75, innerWidth/innerHeight, 0.1, 1000);
const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
renderer.setSize(innerWidth, innerHeight);
renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
document.querySelector('.canvas').appendChild(renderer.domElement);
camera.position.z = 5;
window.addEventListener('resize', () => { camera.aspect = innerWidth/innerHeight; camera.updateProjectionMatrix(); renderer.setSize(innerWidth, innerHeight); });
(function animate() { requestAnimationFrame(animate); renderer.render(scene, camera); })();
```

---

## 13. CSS-Only Effects Library

### Grain Overlay (SVG)
```css
.grain::after { content: ''; position: fixed; inset: -50%; width: 200%; height: 200%; background: url("data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)'/%3E%3C/svg%3E"); opacity: 0.04; pointer-events: none; z-index: 9998; }
```

### Glassmorphism
```css
.glass { background: rgba(255,255,255,0.08); backdrop-filter: blur(12px) saturate(150%); -webkit-backdrop-filter: blur(12px) saturate(150%); border: 1px solid rgba(255,255,255,0.1); border-radius: 16px; }
```

### Gradient Mesh Background
```css
.gradient-mesh { background: radial-gradient(at 20% 30%, oklch(0.5 0.2 280 / 0.15) 0%, transparent 50%), radial-gradient(at 80% 70%, oklch(0.5 0.15 25 / 0.1) 0%, transparent 50%), var(--bg); }
```

### Skeleton Shimmer
```css
.skeleton { background: linear-gradient(90deg, var(--surface) 25%, oklch(0.2 0 0) 50%, var(--surface) 75%); background-size: 200% 100%; animation: shimmer 1.5s infinite; border-radius: 8px; }
@keyframes shimmer { to { background-position: -200% 0; } }
```

### Accordion Height:Auto (No JS)
```css
.accordion-content { display: grid; grid-template-rows: 0fr; transition: grid-template-rows 0.4s cubic-bezier(0.16, 1, 0.3, 1); }
.accordion-content > div { overflow: hidden; }
.accordion.open .accordion-content { grid-template-rows: 1fr; }
```

### Text Gradient
```css
.gradient-text { background: linear-gradient(135deg, var(--text) 0%, var(--accent) 100%); -webkit-background-clip: text; -webkit-text-fill-color: transparent; background-clip: text; }
```

### Scrollbar
```css
html { scrollbar-width: thin; scrollbar-color: var(--muted) var(--bg); }
::selection { background: var(--accent); color: var(--bg); }
```

### Font Smoothing
```css
body { -webkit-font-smoothing: antialiased; -moz-osx-font-smoothing: grayscale; text-rendering: optimizeLegibility; }
```

---

## 14. CSS-Native Animation Power (2025-2026)

### Scroll-Driven View Reveal (No JS!)
```css
.card {
  animation: cardReveal linear both;
  animation-timeline: view();
  animation-range: entry 0% cover 35%;
}
@keyframes cardReveal {
  from { opacity: 0; transform: translateY(60px) scale(0.95); }
  to { opacity: 1; transform: translateY(0) scale(1); }
}
```

### Scroll Progress Bar (No JS!)
```css
.progress-bar {
  position: fixed; top: 0; left: 0; right: 0; height: 3px;
  background: var(--accent); transform-origin: left;
  animation: scaleProgress linear;
  animation-timeline: scroll();
}
@keyframes scaleProgress { from { transform: scaleX(0); } to { transform: scaleX(1); } }
```

### @starting-style for Modal (No JS animation!)
```css
dialog {
  opacity: 0; transform: translateY(20px);
  transition: opacity 0.4s, transform 0.4s, display 0.4s allow-discrete, overlay 0.4s allow-discrete;
}
dialog[open] { opacity: 1; transform: translateY(0); }
@starting-style { dialog[open] { opacity: 0; transform: translateY(20px); } }
dialog::backdrop { background: rgba(0,0,0,0); transition: background 0.4s, display 0.4s allow-discrete, overlay 0.4s allow-discrete; }
dialog[open]::backdrop { background: rgba(0,0,0,0.5); }
@starting-style { dialog[open]::backdrop { background: rgba(0,0,0,0); } }
```

### @property Gradient Animation
```css
@property --gradient-angle { syntax: '<angle>'; initial-value: 0deg; inherits: false; }
.animated-gradient {
  background: conic-gradient(from var(--gradient-angle), oklch(0.7 0.2 25), oklch(0.6 0.2 280), oklch(0.7 0.2 25));
  animation: rotateGradient 4s linear infinite;
}
@keyframes rotateGradient { to { --gradient-angle: 360deg; } }
```

### CSS linear() Spring Easing
```css
:root {
  --spring-smooth: linear(0, 0.009, 0.035 2.1%, 0.141, 0.281 6.7%, 0.723 12.9%, 0.938 16.7%, 1.017, 1.077, 1.121, 1.149 24.3%, 1.159, 1.163, 1.161, 1.154 29.9%, 1.129 32.8%, 1.051 39.6%, 1.017 43.1%, 0.991, 0.977 51%, 0.974 53.8%, 0.975 57.1%, 0.997 69.8%, 1.003 76.9%, 1);
  --spring-bouncy: linear(0, 0.004, 0.016, 0.035, 0.063 5.7%, 0.265 11.8%, 0.554 18.3%, 0.735, 0.874 25.8%, 0.986, 1.066 31.2%, 1.122 33.7%, 1.155 36.4%, 1.165, 1.163 40.6%, 1.142 43.8%, 1.034 53.3%, 0.988 58.2%, 0.968 62.8%, 0.965 67.5%, 0.975 73.9%, 1.002 87.6%, 1);
}
.spring-element { transition: transform 0.6s var(--spring-smooth); }
```

### interpolate-size (height:auto animation!)
```css
:root { interpolate-size: allow-keywords; } /* Add to CSS reset! */
.expandable { height: 0; overflow: hidden; transition: height 0.5s var(--spring-smooth); }
.expandable.open { height: auto; }
```

### Popover Animation (No JS!)
```css
[popover] {
  opacity: 0; transform: translateY(8px) scale(0.96);
  transition: opacity 0.3s, transform 0.3s, display 0.3s allow-discrete, overlay 0.3s allow-discrete;
}
[popover]:popover-open { opacity: 1; transform: translateY(0) scale(1); }
@starting-style { [popover]:popover-open { opacity: 0; transform: translateY(8px) scale(0.96); } }
```

### CSS Anchor Positioning (No JS!)
```css
.trigger { anchor-name: --my-anchor; }
.tooltip { position: fixed; position-anchor: --my-anchor; top: anchor(bottom); left: anchor(center); translate: -50% 8px; }
```

---

## 15. Performance Checklist

- [ ] Fonts: preload critical, font-display: swap, 2 families max
- [ ] Images: lazy load below fold, width/height attrs, WebP/AVIF
- [ ] Animations: ONLY transform, opacity, clip-path (GPU composited)
- [ ] Scroll animations: use CSS scroll-driven API (off main thread) where possible
- [ ] will-change: sparingly, remove after animation
- [ ] content-visibility: auto on below-fold heavy sections
- [ ] prefers-reduced-motion: reduce media query present
- [ ] focus-visible styles on all interactive elements
- [ ] Three.js: setPixelRatio(Math.min(devicePixelRatio, 2))
- [ ] GSAP: matchMedia() for responsive, Context for cleanup
- [ ] Mobile: disable particles/canvas effects on small screens
- [ ] Speculation Rules for instant page loads (if MPA)
